package com.example.galaxy.models

data class User (
    var userId: String,
    var firstName: String,
    var lastName: String,
    var email: String,
)